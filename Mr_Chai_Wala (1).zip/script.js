document.addEventListener('DOMContentLoaded', () => {
    console.log('Website Loaded Successfully!');
});